# Fieldworks

Generative artworks and interactive environments by Brad Necyk.

A surface that answers. A fold in seeing. An unfinished sky. Impossible matter. A river remembering a drawing. A small vocabulary, an expanding field. A field of competing futures. A picture with weight. Eight encounters with the living physics of Cyberdelic OS.

These are living, revisable artworks. They are not Bitcoin inscriptions.
