/* Built-in, local-only speech. The publication and its exact bytes stay intact. */
(function () {
  "use strict";
  var SPEEDS = [.75, 1, 1.25, 1.5];
  var SPEED_KEY = "cyberdelic-listen-speed";
  var METADATA = /^(release|version|date|status|place|authorship note|project|type|author|recorded|first light|sha-?256|hash|content sha256|source|repository|address|inscription|network|content length)\s*:/i;

  function cleanText(text) {
    return String(text || "").replace(/https?:\/\/\S+/g, "")
      .replace(/\b[a-f0-9]{32,}(?:i\d+)?\b/gi, "")
      .replace(/\s+/g, " ").trim();
  }

  function splitText(text) {
    var parts = [];
    var remaining = cleanText(text);
    while (remaining.length > 600) {
      var slice = remaining.slice(0, 600);
      var matches = Array.from(slice.matchAll(/[.!?]["')\]]?\s+/g));
      var end = matches.length ? matches[matches.length - 1].index +
        matches[matches.length - 1][0].length : slice.lastIndexOf(" ");
      if (end < 100) end = 600;
      parts.push(remaining.slice(0, end).trim());
      remaining = remaining.slice(end).trim();
    }
    if (remaining) parts.push(remaining);
    return parts;
  }

  function localVoice(voices, language) {
    var local = voices.filter(function (voice) { return voice.localService === true; });
    var prefix = language.split("-")[0].toLowerCase();
    var matching = local.filter(function (voice) {
      return voice.lang.toLowerCase().split("-")[0] === prefix;
    });
    return matching.find(function (voice) { return voice.default; }) ||
      matching.find(function (voice) { return voice.lang.toLowerCase() === language.toLowerCase(); }) ||
      matching[0] || null;
  }

  function Player(synth, Utterance, chunks, notify, language) {
    this.synth = synth;
    this.Utterance = Utterance;
    this.chunks = chunks;
    this.notify = notify;
    this.language = language || "en";
    this.state = "idle";
    this.index = 0;
    this.offset = 0;
    this.speed = 1;
    this.generation = 0;
    this.message = "";
  }
  Player.prototype.paint = function () { this.notify(this); };
  Player.prototype.speak = function () {
    var self = this;
    var voice = localVoice(this.synth.getVoices(), this.language);
    if (!voice) {
      this.state = "paused";
      this.message = "No local voice is available for this language. Enable an installed voice in your device's speech settings.";
      this.paint();
      return;
    }
    if (this.index >= this.chunks.length) { this.stop(); return; }
    var generation = ++this.generation;
    var start = this.offset;
    var utterance = new this.Utterance(this.chunks[this.index].slice(start));
    utterance.voice = voice;
    utterance.lang = voice.lang;
    utterance.rate = this.speed;
    utterance.onboundary = function (event) {
      if (generation === self.generation && Number.isFinite(event.charIndex)) {
        self.offset = start + event.charIndex;
      }
    };
    utterance.onend = function () {
      if (generation !== self.generation) return;
      self.current = null;
      self.index += 1;
      self.offset = 0;
      if (self.index >= self.chunks.length) { self.stop(); return; }
      if (self.state === "playing") self.speak();
    };
    utterance.onerror = function (event) {
      if (generation !== self.generation) return;
      if (event.error === "canceled" || event.error === "interrupted") {
        self.state = "paused";
      } else {
        self.state = "paused";
        self.message = "Speech stopped. Try resuming, or check your device's installed voices.";
      }
      self.paint();
    };
    this.current = utterance;
    this.state = "playing";
    this.message = "";
    this.paint();
    try { this.synth.speak(utterance); }
    catch (error) { utterance.onerror({ error: "unavailable" }); }
  };
  Player.prototype.toggle = function () {
    if (this.state === "playing") {
      this.synth.pause();
      this.state = "paused";
      this.paint();
    } else if (this.state === "paused" && this.current && this.synth.paused) {
      this.state = "playing";
      this.message = "";
      this.synth.resume();
      this.paint();
    } else {
      // Resume before cancel to clear browsers that keep a paused queue.
      this.generation += 1;
      this.synth.resume();
      this.synth.cancel();
      this.speak();
    }
  };
  Player.prototype.setSpeed = function (speed) {
    if (SPEEDS.indexOf(speed) === -1) return;
    this.speed = speed;
    if (this.state !== "idle") {
      var playing = this.state === "playing";
      this.generation += 1;
      this.current = null;
      this.synth.resume();
      this.synth.cancel();
      if (playing) this.speak();
    }
    this.paint();
  };
  Player.prototype.stop = function () {
    this.generation += 1;
    this.current = null;
    this.synth.cancel();
    this.state = "idle";
    this.index = 0;
    this.offset = 0;
    this.message = "";
    this.paint();
  };

  function readingChunks(article) {
    var root = article.querySelector(".living-reading .markdown-body, .markdown-reading .markdown-body");
    var elements;
    if (article.classList.contains("correspondence-page")) {
      elements = article.querySelectorAll(".corr-lede p, .corr-section h2, .thread-head h3, .stake, .turn-who, .turn blockquote p, .gloss");
    } else if (root) {
      elements = root.querySelectorAll("h1,h2,h3,h4,p,li");
    } else { return []; }
    var chunks = [];
    Array.prototype.forEach.call(elements, function (element) {
      if (element.closest("pre,table,nav,aside,[hidden]")) return;
      if (element.tagName === "P" && element.closest("li")) return;
      if (element.tagName === "LI" && element.querySelector("li")) return;
      var text = cleanText(element.textContent);
      if (!text || METADATA.test(text) || /^Field Note \d+$/i.test(text)) return;
      chunks = chunks.concat(splitText(text));
    });
    return chunks;
  }

  function initialise() {
    var article = document.querySelector("article.living-page");
    var head = article && article.querySelector(".living-head");
    var kind = head && head.querySelector(".shelf-kind");
    var title = head && head.querySelector("h1");
    if (!head || head.querySelector(".listen-controls")) return;
    if (!article.classList.contains("correspondence-page") &&
        !(kind && /field notes|builder notes|correspondence/i.test(kind.textContent)) &&
        !(title && /field notes|builder notes|correspondence/i.test(title.textContent))) return;
    var chunks = readingChunks(article);
    if (!chunks.length) return;
    var controls = document.createElement("div");
    controls.className = "listen-controls";
    controls.setAttribute("role", "group");
    controls.setAttribute("aria-label", "Read aloud");
    var button = document.createElement("button");
    button.type = "button";
    var icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("viewBox", "0 0 12 12");
    icon.setAttribute("aria-hidden", "true");
    var path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("fill", "currentColor");
    icon.appendChild(path);
    var label = document.createElement("span");
    button.append(icon, label);
    var speedLabel = document.createElement("label");
    speedLabel.className = "listen-speed";
    speedLabel.appendChild(document.createTextNode("Speed"));
    var speed = document.createElement("select");
    speed.setAttribute("aria-label", "Reading speed");
    SPEEDS.forEach(function (value) {
      var option = document.createElement("option");
      option.value = value;
      option.textContent = value + "×";
      speed.appendChild(option);
    });
    var saved = 1;
    try { saved = Number(localStorage.getItem(SPEED_KEY)) || 1; } catch (error) { /* optional */ }
    speed.value = SPEEDS.indexOf(saved) === -1 ? "1" : String(saved);
    speedLabel.appendChild(speed);
    var status = document.createElement("p");
    status.className = "listen-status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    controls.append(button, speedLabel, status);
    head.insertBefore(controls, head.querySelector(".stone"));
    function paint(player) {
      var playing = player.state === "playing";
      label.textContent = playing ? "Pause" : player.state === "paused" ? "Resume" : "Listen";
      path.setAttribute("d", playing ? "M2 1h3v10H2zM7 1h3v10H7z" : "M2 1v10l9-5z");
      button.setAttribute("aria-label", playing ? "Pause reading" : player.state === "paused" ? "Resume reading" : "Listen to this publication");
      button.setAttribute("aria-pressed", String(playing));
      status.textContent = player.message;
    }
    if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
      paint({ state: "idle", message: "Read aloud is not supported in this browser." });
      button.disabled = true;
      speed.disabled = true;
      return;
    }
    var player = new Player(window.speechSynthesis, window.SpeechSynthesisUtterance,
      chunks, paint, document.documentElement.lang || "en");
    player.speed = Number(speed.value);
    paint(player);
    // Prime asynchronous voice discovery without starting any audio.
    window.speechSynthesis.getVoices();
    button.addEventListener("click", function () { player.toggle(); });
    speed.addEventListener("change", function () {
      player.setSpeed(Number(speed.value));
      try { localStorage.setItem(SPEED_KEY, speed.value); } catch (error) { /* optional */ }
    });
    window.addEventListener("pagehide", function () { player.stop(); });
    document.addEventListener("visibilitychange", function () {
      if (document.hidden && player.state === "playing") player.toggle();
    });
    window.addEventListener("hashchange", function () { player.stop(); });
  }

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { Player: Player, splitText: splitText, cleanText: cleanText,
      localVoice: localVoice, readingChunks: readingChunks };
  } else {
    // The existing Markdown renderer finishes before this optional control.
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () { setTimeout(initialise, 0); });
    } else { setTimeout(initialise, 0); }
  }
})();
